import numpy as np
from scipy.optimize import root

from ..config.Constants import MWs_l, MWs_v, column_params, packing_params, n
from ..Properties.Thermophysical_Properties import vapor_pressure


def convert_data(
        df,
        run=0,
        type='mole',
        return_metadata=False,
        vapor_composition_mode='legacy_ratio',
        gas_flow_basis='reported_total_wet',
):

    X = df.iloc[run, :].to_numpy()
    case_id = str(df.index[run])
    intercoolers = int(df.iloc[run]["Intercoolers"]) if "Intercoolers" in df.columns else 0

    if type == 'mole':
        L_G, Fv_T, alpha, w_MEA_unloaded, y_CO2, Tl_z, Tv_0, P, beds = X[:9]

        # Molecular Weights
        MW_CO2 = MWs_l[0]
        MW_MEA = MWs_l[1]
        MW_H2O = MWs_l[2]
        MW_N2 = MWs_v[2]
        MW_O2 = MWs_v[3]

        alpha_O2_N2 = 0.08485753604
        alpha_H2O_CO2 = 0.9626010166

        # Liquid Calculations
        Fl_T = L_G * Fv_T

        x_MEA_unloaded = w_MEA_unloaded / (MW_MEA / MW_H2O + w_MEA_unloaded * (1 - MW_MEA / MW_H2O))
        x_H2O_unloaded = 1 - x_MEA_unloaded

        Fl_MEA_b = Fl_T * x_MEA_unloaded
        Fl_H2O_b = Fl_T * x_H2O_unloaded

        Fl_CO2_b = Fl_MEA_b * alpha
        Fl = [Fl_CO2_b, Fl_MEA_b, Fl_H2O_b]

        # Vapor Calculations

        # Find Vapor Mole Fractions
        y_CO2, y_H2O, y_N2, y_O2 = _vapor_mole_fractions(
            df,
            run,
            y_CO2,
            Tv_0,
            P,
            alpha_H2O_CO2,
            alpha_O2_N2,
            vapor_composition_mode,
        )

        # Find Vapor Molar Flow Rates
        Fv_CO2_a = y_CO2 * Fv_T  # mole/s
        Fv_H2O_a = y_H2O * Fv_T  # mole/s
        Fv_N2_a = y_N2 * Fv_T  # mole/s
        Fv_O2_a = y_O2 * Fv_T  # mole/s
        Fv = [Fv_CO2_a, Fv_H2O_a, Fv_N2_a, Fv_O2_a]

    elif type == 'mass':

        m_T_l, m_T_v, alpha, w_MEA_unloaded, y_CO2, Tl_z, Tv_0, P, beds = X[:9]
        if gas_flow_basis not in {"reported_total_wet", "reported_dry_mass"}:
            raise ValueError(f"Unknown gas_flow_basis: {gas_flow_basis}")
        if gas_flow_basis == "reported_dry_mass" and vapor_composition_mode != "dry_saturated":
            raise ValueError("gas_flow_basis='reported_dry_mass' requires vapor_composition_mode='dry_saturated'")

        D = column_params['NCCC']['D']
        H = column_params['NCCC']['H'] * beds

        a_p = packing_params['MellapakPlus252Y']['a_p']
        ϵ = packing_params['MellapakPlus252Y']['eps']
        Clp = packing_params['MellapakPlus252Y']['Cl']
        Cvp = packing_params['MellapakPlus252Y']['Cv']
        Cs = packing_params['MellapakPlus252Y']['Cs']
        Cp_0 = packing_params['MellapakPlus252Y']['Cp_0']
        Ch = packing_params['MellapakPlus252Y']['Ch']

        packing = a_p, ϵ, Clp, Cvp, Cs, Cp_0, Ch

        A = np.pi * .25 * D ** 2
        z = np.linspace(0, H, n)

        # Molecular Weights
        MW_CO2 = MWs_l[0]
        MW_MEA = MWs_l[1]
        MW_H2O = MWs_l[2]
        MW_N2 = MWs_v[2]
        MW_O2 = MWs_v[3]

        alpha_O2_N2 = 0.08485753604
        alpha_H2O_CO2 = 0.9626010166

        # Liquid Calculations

        # Find Liquid Mass Flow Rates

        w_H2O_unloaded = 1 - w_MEA_unloaded

        unloaded_mass = m_T_l / (1.0 + alpha * w_MEA_unloaded * MW_CO2 / MW_MEA)
        m_MEA_l = w_MEA_unloaded * unloaded_mass  # kg/s
        m_H2O_l = w_H2O_unloaded * unloaded_mass  # kg/s

        Fl_MEA_b = m_MEA_l/MW_MEA
        Fl_H2O_b = m_H2O_l/MW_H2O
        Fl_T_unloaded = Fl_MEA_b + Fl_H2O_b
        Fl_CO2_b = Fl_MEA_b * alpha
        Fl = [Fl_CO2_b, Fl_MEA_b, Fl_H2O_b]
        Fl_T = sum(Fl)

        # Vapor Calculations

        # Find Vapor Mole Fractions
        y_CO2, y_H2O, y_N2, y_O2 = _vapor_mole_fractions(
            df,
            run,
            y_CO2,
            Tv_0,
            P,
            alpha_H2O_CO2,
            alpha_O2_N2,
            vapor_composition_mode,
        )
        if gas_flow_basis == "reported_dry_mass":
            wet_factor = 1.0 - y_H2O
            dry_y_CO2 = y_CO2 / wet_factor
            dry_y_N2 = y_N2 / wet_factor
            dry_y_O2 = y_O2 / wet_factor
            dry_sigma = dry_y_N2 * MW_N2 + dry_y_O2 * MW_O2 + dry_y_CO2 * MW_CO2
            Fv_dry = m_T_v / dry_sigma
            Fv_CO2 = dry_y_CO2 * Fv_dry
            Fv_N2 = dry_y_N2 * Fv_dry
            Fv_O2 = dry_y_O2 * Fv_dry
            Fv_H2O = (y_H2O / wet_factor) * Fv_dry
        else:
            sigma = y_N2 * MW_N2 + y_O2 * MW_O2 + y_CO2 * MW_CO2 + y_H2O * MW_H2O

            # Find Vapor Mass Flow Rates

            w_CO2_v = y_CO2 * MW_CO2 / sigma
            w_H2O_v = y_H2O * MW_H2O / sigma
            w_N2_v = y_N2 * MW_N2 / sigma
            w_O2_v = y_O2 * MW_O2 / sigma

            m_CO2_v = w_CO2_v * m_T_v
            m_H2O_v = w_H2O_v * m_T_v
            m_N2_v = w_N2_v * m_T_v
            m_O2_v = w_O2_v * m_T_v

            # Find Vapor Molar Flow Rates
            Fv_CO2 = m_CO2_v / MW_CO2  # mole/s
            Fv_H2O = m_H2O_v / MW_H2O  # mole/s
            Fv_N2 = m_N2_v / MW_N2  # mole/s
            Fv_O2 = m_O2_v / MW_O2  # mole/s

        Fv = [Fv_CO2, Fv_H2O, Fv_N2, Fv_O2]
        Fv_T = sum(Fv)

        L_G = Fl_T_unloaded/Fv_T

        X = L_G, Fv_T, alpha, w_MEA_unloaded, y_CO2, Tl_z, Tv_0, P, beds

    else:
        raise ValueError('Wrong Data Type')

    D = float(df.iloc[run]["D"]) if "D" in df.columns else column_params['NCCC']['D']
    single_bed_height = (
        float(df.iloc[run]["H"])
        if "H" in df.columns
        else float(df.iloc[run]["single_bed_height_m"])
        if "single_bed_height_m" in df.columns
        else column_params['NCCC']['H']
    )
    H = single_bed_height * beds

    a_p = packing_params['MellapakPlus252Y']['a_p']
    ϵ = packing_params['MellapakPlus252Y']['eps']
    Clp = packing_params['MellapakPlus252Y']['Cl']
    Cvp = packing_params['MellapakPlus252Y']['Cv']
    Cs = packing_params['MellapakPlus252Y']['Cs']
    Cp_0 = packing_params['MellapakPlus252Y']['Cp_0']
    Ch = packing_params['MellapakPlus252Y']['Ch']

    packing = a_p, ϵ, Clp, Cvp, Cs, Cp_0, Ch

    A = np.pi * .25 * D ** 2
    z = np.linspace(0, 1, n)


    inputs = [Fl, Fv, Tl_z, Tv_0, z, H, A, P, packing]
    if return_metadata:
        metadata = {
            "case_id": case_id,
            "beds": int(beds),
            "intercoolers": intercoolers,
            "single_bed_height_m": float(single_bed_height),
            "total_packed_height_m": float(H),
            "diameter_m": float(D),
            "vapor_composition_mode": vapor_composition_mode,
            "gas_flow_basis": gas_flow_basis,
        }
        return inputs, X, metadata
    return inputs, X


def _vapor_mole_fractions(df, run, y_CO2, Tv, P, alpha_H2O_CO2, alpha_O2_N2, vapor_composition_mode):
    y_H2O = _optional_fraction(df, run, "y_H2O")
    if y_H2O is None:
        y_H2O = y_CO2 * alpha_H2O_CO2

    if vapor_composition_mode == "dry_saturated":
        y_H2O = float(np.clip(vapor_pressure(Tv) / P, 0.0, 0.95))
        dry_y_co2 = float(y_CO2)
        dry_y_o2 = float(df.iloc[run]["y_O2"]) if "y_O2" in df.columns else None
        if dry_y_o2 is None:
            dry_y_N2 = (1.0 - dry_y_co2) / (1.0 + alpha_O2_N2)
            dry_y_o2 = dry_y_N2 * alpha_O2_N2
        dry_y_N2 = 1.0 - dry_y_co2 - dry_y_o2
        wet_factor = 1.0 - y_H2O
        y_CO2 = dry_y_co2 * wet_factor
        y_O2 = dry_y_o2 * wet_factor
        y_N2 = dry_y_N2 * wet_factor
    elif vapor_composition_mode == "input_o2" and "y_O2" in df.columns:
        y_O2 = float(df.iloc[run]["y_O2"])
        y_N2 = 1.0 - y_CO2 - y_H2O - y_O2
    elif vapor_composition_mode == "legacy_ratio":
        y_N2 = (1.0 - y_CO2 - y_H2O) / (1.0 + alpha_O2_N2)
        y_O2 = y_N2 * alpha_O2_N2
    else:
        raise ValueError(f"Unknown vapor_composition_mode: {vapor_composition_mode}")

    if min(y_CO2, y_H2O, y_N2, y_O2) <= 0.0:
        raise ValueError(
            "Vapor composition reconstruction produced a nonpositive mole fraction: "
            f"y_CO2={y_CO2}, y_H2O={y_H2O}, y_N2={y_N2}, y_O2={y_O2}"
        )
    total = y_CO2 + y_H2O + y_N2 + y_O2
    if not np.isclose(total, 1.0, rtol=0.0, atol=1.0e-8):
        raise ValueError(f"Vapor mole fractions do not sum to one: {total}")
    return y_CO2, y_H2O, y_N2, y_O2


def _optional_fraction(df, run, column):
    if column not in df.columns:
        return None
    value = df.iloc[run][column]
    if value is None or not np.isfinite(float(value)):
        return None
    return float(value)

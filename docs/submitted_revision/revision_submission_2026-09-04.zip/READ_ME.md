# Revision package — Next Chemical Engineering

Prepared 4 September 2026 for Tanner W. Polley and John D. Hedengren.

## Files for review

- `revised_manuscript.pdf`: polished 33-page manuscript, including Table 11 on page 31.
- `response_to_reviewers.pdf`: nine-page point-by-point response to all 20 numbered comments, with final manuscript page references.
- `cover_letter.pdf`: one-page letter to Next Chemical Engineering.
- `original_manuscript.pdf`: unchanged, author-confirmed 29-page original for the redline.
- `revised_source/` and `original_source/`: self-contained LaTeX source folders; compile `main.tex` with XeLaTeX and BibTeX through `latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=builds main.tex`.
- `cover_letter.docx` and `response_to_reviewers.docx`: editable letters; their Markdown copies are also included.
- `SHA256SUMS.txt`: file checksums for this package.

Page references in the response refer to the clean revised manuscript, not a future redline. The original and revised source folders are supplied so Professor Hedengren can generate that redline as requested. A red-marked manuscript has not been generated here.

## Original manuscript identity

The author confirmed on 4 September 2026 that the preserved May 10 manuscript is the original to use. Its PDF is the byte-for-byte pre-review copy documented in `docs/reviewer_quick_revision_report.md`, with SHA-256 `09b8ce8226c7e9e083339deb2231adff9eca5b37171f1b9c03d178ea07c16f62`.

The accompanying manuscript source and bibliography are unchanged from source commit `c4726f69fdc034f5bec817ab720239967084ecdf`. Rebuilding this source produces the same 29 pages and identical PDF text after whitespace normalization. The preserved PDF, rather than that rebuilt copy, is included.

Elsevier CAS support files needed to compile the original are supplied from the [CTAN Elsevier CAS distribution](https://mirrors.mit.edu/CTAN/macros/latex/contrib/els-cas-templates/). These are build support, not changes to the original manuscript. The revised source includes the support files used for its verified build. Both folders retain their own bibliography; do not replace the original bibliography with the revised one when generating the redline.

## Checks completed

Both source packages compile. The revised source rebuild matches the supplied revised PDF text after whitespace normalization. All 20 numbered reviewer comments are reproduced verbatim and each has a response and manuscript locations. The revised manuscript has no unresolved cross-references/citations or prohibited words. Its displayed governing equations, existing parameter-table values and plotted numerical CSVs are unchanged by this polishing pass. No new scientific analyses or experiments were performed.

## Before journal upload

Fable completed the final editorial review and found no blocking issues. The author-approved optional polish has now been applied: consistent number formatting, clearer refinement wording, Table 11 naming and top-of-page placement, with matching letter references. The manuscript retains the author-approved `nce-revision-v3` code tag reference; creating/publishing that tag remains the author's release step. The final LaTeX source was pushed to Overleaf and verified at commit `794735d463f9f9a640829647b15bd2db34905bfc`; the original manuscript, letters and this bundle are excluded from that mirror. No email or journal submission is performed by this task. The cover letter identifies the manuscript by title because no manuscript ID was supplied.

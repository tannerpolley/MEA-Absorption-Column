# Supporting manuscript results

The isothermal control uses constructed C3 feeds and common conventional transport at 313.15 K. It is not experimental validation or the primary ePC-SAFT comparison. The two result files retain both initial meshes and original dependency/source identities. Plotted values use the 33-point initial mesh. The calibrated source files match the hashes in the result record; generic dependencies remain identified there. The original absorber adapter is identified by its recorded hash, not replaced with its subsequently edited working copy.

The numerical result is a local derivative-assembly check at a synthetic state. Its historical Engine identity and retained errors are in node-verification/result.json; the test definition supplies state and direction construction. This record does not assert full-column solution agreement or performance.

These files were selected for the two scoped manuscript additions; no model was run to create this supplement. Source records include development metadata for reproducibility and are not manuscript narrative.
